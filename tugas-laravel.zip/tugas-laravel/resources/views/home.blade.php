@extends('layouts.main')

@section('container')
<div class="container" >
<h1>Selamat Datang</h1> 
<h1>いらしゃいませ</h1>
<h1>Welcome</h1>
<h1>أهْلاً وَسَهْلاً</h1>
</div>
@endsection