@extends('layouts.main')

@section('container')
<div class="card" style="margin-top: 20px; width: 50rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Profile Pembuat</li>
    <li class="list-group-item">Nama : Fauza Ibrahim Farid</li>
    <li class="list-group-item">Mentor : Rizky Bagus</li>
    <li class="list-group-item">Kampus : Institut Teknologi Telkom Purwokerto</li>  
  </ul>
</div>
@endsection