@extends('layouts.main')

@section('container')
<div class="card" style="width: 8rem;">
  <div class="card-body">
    Tentang ITTP
  </div>
</div>

<div class="card" style="margin-top: 20px;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Sambutan Rektor</li>
    <li class="list-group-item">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint provident tempora possimus at, ipsum molestiae, reprehenderit neque autem eaque dignissimos impedit rem quibusdam vitae iste ad aspernatur beatae quasi aut alias ex atque perferendis rerum vero doloribus? Dolores placeat sit harum officia quo, odio modi hic veniam? Eius amet, excepturi nihil earum sed aliquam dolor quidem explicabo deserunt quaerat culpa quo sint est error sequi repudiandae vero. Explicabo animi, quo vero a vitae, aut nisi iusto ratione incidunt veniam ab voluptates eius totam ipsa sapiente molestias voluptatum laborum excepturi repellat reprehenderit? Voluptatibus esse debitis et doloremque cum omnis eveniet asperiores?</li>  
  </ul>
</div>
@endsection