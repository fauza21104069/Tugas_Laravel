

<?php $__env->startSection('container'); ?>
<div class="card" style="margin-top: 20px; width: 50rem;">
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Profile Pembuat</li>
    <li class="list-group-item">Nama : Fauza Ibrahim Farid</li>
    <li class="list-group-item">Mentor : Rizky Bagus</li>
    <li class="list-group-item">Kampus : Institut Teknologi Telkom Purwokerto</li>  
  </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\IT TELKOM PURWOKERTO\# YA ALLAH SEMESTER 5\MSIB\Laravel\tugas-laravel\resources\views/profile.blade.php ENDPATH**/ ?>